Language English

In This folder , please put the .txt files that contains the sentences you want to generate
For each .txt file , a .wav file with the same name will be generated and situated in the folder named :  "Generated-data"

